    </div> <!-- Closing container -->
    <footer class="text-center mt-5">
        <p>&copy; 2024 Sistem Absensi</p>
    </footer>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/scripts.js"></script> <!-- JavaScript tambahan -->
</body>
</html>
