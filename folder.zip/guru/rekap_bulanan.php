<?php
include '../config.php';

// Mengambil tahun-tahun dari database atau mendefinisikan secara manual (3 tahun terakhir hingga tahun ini)
$years = range(date('Y') - 3, date('Y'));

// Ambil data kelas dari database untuk dropdown
$stmt = $conn->query("SELECT * FROM kelas");
$kelasList = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Definisi bulan
$months = [
    '01' => 'Januari',
    '02' => 'Februari',
    '03' => 'Maret',
    '04' => 'April',
    '05' => 'Mei',
    '06' => 'Juni',
    '07' => 'Juli',
    '08' => 'Agustus',
    '09' => 'September',
    '10' => 'Oktober',
    '11' => 'November',
    '12' => 'Desember'
];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tahun = $_POST['tahun'];
    $bulan = $_POST['bulan'];
    $kelas_id = $_POST['kelas_id'] ?? '';

    // Query untuk menyertakan filter kelas jika dipilih
    $sql = "SELECT s.nama, k.nama_kelas, 
            SUM(a.keterangan = 'alpha') as total_alpha,
            SUM(a.keterangan = 'sakit') as total_sakit,
            SUM(a.keterangan = 'izin') as total_izin
            FROM absensi a 
            JOIN siswa s ON a.siswa_id = s.id 
            JOIN kelas k ON s.kelas_id = k.id 
            WHERE YEAR(a.tanggal) = :tahun AND MONTH(a.tanggal) = :bulan";

    // Tambahkan filter kelas jika dipilih
    if (!empty($kelas_id)) {
        $sql .= " AND s.kelas_id = :kelas_id";
    }

    $sql .= " GROUP BY s.id, k.id
              ORDER BY k.nama_kelas, s.nama";
    
    $stmt = $conn->prepare($sql);
    $params = ['tahun' => $tahun, 'bulan' => $bulan];
    
    if (!empty($kelas_id)) {
        $params['kelas_id'] = $kelas_id;
    }

    $stmt->execute($params);
    $rekap = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../img/logo.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Absensi</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        .form-container {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            display: flex;
            gap: 10px;
            align-items: center;
            flex-wrap: wrap;
        }

        select, input[type="submit"], .download-button {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            transition: border-color 0.3s;
        }

        select:focus, input[type="submit"]:focus, .download-button:focus {
            border-color: #007BFF;
            outline: none;
        }

        input[type="submit"] {
            background-color: #007BFF;
            color: white;
            cursor: pointer;
            border: none;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .download-button {
            background-color: #28a745;
            color: white;
            cursor: pointer;
            border: none;
        }

        .download-button:hover {
            background-color: #218838;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: left;
        }

        th {
            background-color: #007BFF;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        @media (max-width: 600px) {
            .form-container {
                flex-direction: column;
                align-items: stretch;
            }

            select, input[type="submit"], .download-button {
                width: 100%;
                margin-bottom: 10px;
            }

            .form-group {
                flex-direction: column;
                align-items: stretch;
            }
        }
    </style>
</head>
<body>
    <h1>Rekap Absensi</h1>
    <div class="form-container">
        <div class="form-group">
            <form method="post" action="">
                <label for="tahun">Tahun:</label>
                <select name="tahun" id="tahun" required>
                    <?php foreach ($years as $year): ?>
                        <option value="<?= $year ?>" <?= (isset($tahun) && $tahun == $year) ? 'selected' : '' ?>>
                            <?= $year ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <label for="bulan">Bulan:</label>
                <select name="bulan" id="bulan" required>
                    <?php foreach ($months as $key => $month): ?>
                        <option value="<?= $key ?>" <?= (isset($bulan) && $bulan == $key) ? 'selected' : '' ?>>
                            <?= $month ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <label for="kelas">Kelas:</label>
                <select name="kelas_id" id="kelas">
                    <option value="">Semua Kelas</option>
                    <?php foreach ($kelasList as $k): ?>
                        <option value="<?= $k['id'] ?>" <?= (isset($kelas_id) && $kelas_id == $k['id']) ? 'selected' : '' ?>>
                            <?= $k['nama_kelas'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <input type="submit" value="Cek Rekap">  
            </form>

            <?php if (isset($rekap)): ?>
                <form method="post" action="download_excel.php">
                    <input type="hidden" name="tahun" value="<?= htmlspecialchars($tahun) ?>">
                    <input type="hidden" name="bulan" value="<?= htmlspecialchars($bulan) ?>">
                    <input type="hidden" name="kelas_id" value="<?= htmlspecialchars($kelas_id ?? '') ?>">
                    <input type="submit" class="download-button" value="Download Excel">
                </form>
            <?php endif; ?>
        </div>
    </div>

    <?php if (isset($rekap)): ?>
        <h2>Rekap Absensi Bulan <?= htmlspecialchars($months[$bulan]) ?> Tahun <?= htmlspecialchars($tahun) ?> <?= !empty($kelas_id) ? "Kelas " . $kelasList[array_search($kelas_id, array_column($kelasList, 'id'))]['nama_kelas'] : '' ?></h2>
        <table>
            <tr>
                <th>No</th>
                <th>Nama Siswa</th>
                <th>Kelas</th>
                <th>Total Alpha</th>
                <th>Total Sakit</th>
                <th>Total Izin</th>
            </tr>
            <?php if (count($rekap) > 0): ?>
                <?php $no = 1; ?>
                <?php foreach ($rekap as $r): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= htmlspecialchars($r['nama']) ?></td>
                    <td><?= htmlspecialchars($r['nama_kelas']) ?></td>
                    <td><?= htmlspecialchars($r['total_alpha']) ?></td>
                    <td><?= htmlspecialchars($r['total_sakit']) ?></td>
                    <td><?= htmlspecialchars($r['total_izin']) ?></td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">Tidak ada data absensi untuk bulan ini.</td>
                </tr>
            <?php endif; ?>
        </table>
    <?php endif; ?>
</body>
</html>