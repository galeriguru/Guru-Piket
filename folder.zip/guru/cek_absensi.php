<?php
include '../config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tanggal = $_POST['tanggal'];

    try {
        // Query to get classes with NIHIL status
        $nihilQuery = "
            SELECT k.nama_kelas
            FROM kelas k
            LEFT JOIN kelas_absensi ka ON ka.kelas_id = k.id AND ka.tanggal = :tanggal
            WHERE ka.id IS NOT NULL
            AND NOT EXISTS (
                SELECT 1
                FROM absensi a
                JOIN siswa s ON a.siswa_id = s.id
                WHERE s.kelas_id = k.id
                AND a.tanggal = :tanggal
                AND a.keterangan IN ('alpha', 'izin', 'sakit')
            )
            GROUP BY k.id";

        // Query to get individual absent students
        $absentQuery = "
            SELECT k.nama_kelas, s.nama, a.keterangan
            FROM absensi a 
            JOIN siswa s ON a.siswa_id = s.id 
            JOIN kelas k ON s.kelas_id = k.id 
            WHERE a.tanggal = :tanggal 
            AND a.keterangan IN ('alpha', 'izin', 'sakit')
            ORDER BY k.nama_kelas, s.nama";

        // Execute queries
        $stmtNihil = $conn->prepare($nihilQuery);
        $stmtNihil->execute(['tanggal' => $tanggal]);
        $nihilClasses = $stmtNihil->fetchAll(PDO::FETCH_ASSOC);

        $stmtAbsent = $conn->prepare($absentQuery);
        $stmtAbsent->execute(['tanggal' => $tanggal]);
        $absentStudents = $stmtAbsent->fetchAll(PDO::FETCH_ASSOC);

        // Query to get classes with no attendance input
        $noInputQuery = "
            SELECT k.nama_kelas
            FROM kelas k
            LEFT JOIN kelas_absensi ka ON ka.kelas_id = k.id AND ka.tanggal = :tanggal
            LEFT JOIN absensi a ON a.siswa_id IN (SELECT id FROM siswa WHERE kelas_id = k.id) AND a.tanggal = :tanggal
            WHERE ka.id IS NULL AND a.id IS NULL
            GROUP BY k.id";

        // Execute query to get classes with no attendance input
        $stmtNoInput = $conn->prepare($noInputQuery);
        $stmtNoInput->execute(['tanggal' => $tanggal]);
        $noInputClasses = $stmtNoInput->fetchAll(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cek Absensi Siswa</title>
    <link rel="icon" href="../img/logo.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2563eb;
            --success-color: #16a34a;
            --warning-color: #ea580c;
            --danger-color: #dc2626;
            --info-color: #0284c7;
            --background-color: #f8fafc;
            --card-background: #ffffff;
            --text-primary: #1e293b;
            --text-secondary: #64748b;
            --border-color: #e2e8f0;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--background-color);
            color: var(--text-primary);
            line-height: 1.6;
            padding: 2rem;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .header {
            text-align: center;
            margin-bottom: 2rem;
        }

        .header h1 {
            font-size: 2rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 0.5rem;
        }

        .date-form {
            background: var(--card-background);
            padding: 2rem;
            border-radius: 1rem;
            box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            max-width: 400px;
            margin: 0 auto 2rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-label {
            display: block;
            font-weight: 500;
            margin-bottom: 0.5rem;
            color: var(--text-primary);
        }

        .form-control {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid var(--border-color);
            border-radius: 0.5rem;
            font-size: 1rem;
            transition: border-color 0.15s ease-in-out;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .btn {
            display: inline-block;
            padding: 0.75rem 1.5rem;
            font-weight: 500;
            text-align: center;
            border-radius: 0.5rem;
            transition: all 0.15s ease-in-out;
            border: none;
            cursor: pointer;
            width: 100%;
        }

        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background-color: #1d4ed8;
        }

        .content {
            margin-top: 2rem;
        }

        .section {
            background: var(--card-background);
            border-radius: 1rem;
            box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            overflow: hidden;
            margin-bottom: 2rem;
        }

        .section-header {
            padding: 1.5rem;
            background-color: var(--primary-color);
            color: white;
        }

        .section-header h2 {
            font-size: 1.25rem;
            font-weight: 600;
            margin: 0;
        }

        .nihil-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 1rem;
            padding: 1.5rem;
        }

        .nihil-card {
            background: #f0fdf4;
            border: 1px solid #86efac;
            padding: 1rem;
            border-radius: 0.75rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: transform 0.2s ease;
        }

        .noinput-card {
            background: #fef2f2; /* Warna merah muda sebagai background */
            border: 1px solid #dc2626; /* Warna merah danger */
            padding: 1rem;
            border-radius: 0.75rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: transform 0.2s ease;
        }


        .nihil-card:hover {
            transform: translateY(-2px);
        }

        .nihil-class {
            font-weight: 500;
            color: var(--success-color);
        }

        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 9999px;
            font-weight: 500;
            font-size: 0.875rem;
            text-transform: uppercase;
        }

        .status-nihil {
            background-color: #dcfce7;
            color: var(--success-color);
        }

        .status-alpha {
            background-color: #fee2e2;
            color: var(--danger-color);
        }

        .status-izin {
            background-color: #e0f2fe;
            color: var(--info-color);
        }

        .status-sakit {
            background-color: #fff7ed;
            color: var(--warning-color);
        }

        .table-container {
            overflow-x: auto;
            padding: 1.5rem;
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
        }

        th {
            background-color: #f8fafc;
            padding: 1rem;
            text-align: left;
            font-weight: 600;
            color: var(--text-primary);
            border-bottom: 2px solid var(--border-color);
        }

        td {
            padding: 1rem;
            border-bottom: 1px solid var(--border-color);
            color: var(--text-secondary);
        }

        tr:last-child td {
            border-bottom: none;
        }

        .no-data {
            text-align: center;
            padding: 3rem;
            color: var(--text-secondary);
            font-weight: 500;
        }

        @media (max-width: 768px) {
            body {
                padding: 1rem;
            }

            .nihil-grid {
                grid-template-columns: 1fr;
            }

            .date-form {
                padding: 1.5rem;
            }

            .table-container {
                padding: 1rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Cek Absensi Siswa</h1>
        </div>

        <form class="date-form" method="post" action="cek_absensi.php">
            <div class="form-group">
                <label class="form-label" for="tanggal">Tanggal Absensi:</label>
                <input type="date" name="tanggal" id="tanggal" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Tampilkan Absensi</button>
        </form>

        <?php if (isset($nihilClasses) || isset($absentStudents) || isset($noInputClasses)): ?>
            <div class="content">
                <?php if (count($nihilClasses) > 0): ?>
                    <div class="section">
                        <div class="section-header">
                            <h2>Kelas dengan Kehadiran Penuh</h2>
                        </div>
                        <div class="nihil-grid">
                            <?php foreach ($nihilClasses as $class): ?>
                                <div class="nihil-card">
                                    <span class="nihil-class"><?= htmlspecialchars($class['nama_kelas']) ?></span>
                                    <span class="status-badge status-nihil">NIHIL</span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if (count($absentStudents) > 0): ?>
                    <div class="section">
                        <div class="section-header">
                            <h2>Daftar Ketidakhadiran</h2>
                        </div>
                        <div class="table-container">
                            <table>
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Kelas</th>
                                        <th>Nama Siswa</th>
                                        <th>Keterangan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 1; ?>
                                    <?php foreach ($absentStudents as $student): ?>
                                        <tr>
                                            <td><?= $no++ ?></td>
                                            <td><?= htmlspecialchars($student['nama_kelas']) ?></td>
                                            <td><?= htmlspecialchars($student['nama']) ?></td>
                                            <td>
                                                <span class="status-badge status-<?= strtolower($student['keterangan']) ?>">
                                                    <?= strtoupper(htmlspecialchars($student['keterangan'])) ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if (count($noInputClasses) > 0): ?>
                    <div class="section">
                        <div class="section-header">
                            <h2>Kelas yang Belum Input Kehadiran</h2>
                        </div>
                        <div class="nihil-grid">
                            <?php foreach ($noInputClasses as $class): ?>
                                <div class="noinput-card">
                                    <span class="nihil-class"><?= htmlspecialchars($class['nama_kelas']) ?></span>
                                    <span class="status-badge">Belum Input</span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if (count($nihilClasses) == 0 && count($absentStudents) == 0 && count($noInputClasses) == 0): ?>
                    <div class="section">
                        <div class="no-data">
                            Tidak ada data absensi untuk tanggal ini.
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>