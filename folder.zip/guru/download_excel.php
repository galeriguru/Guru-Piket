<?php
require '../vendor/autoload.php';  // Pastikan jalur ini sesuai dengan letak autoload.php Anda

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

include '../config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tahun = $_POST['tahun'];
    $kelas_id = $_POST['kelas_id'] ?? '';

    // Query untuk mengambil data absensi
    $sql = "SELECT s.nama, k.nama_kelas, 
            SUM(a.keterangan = 'alpha') as total_alpha,
            SUM(a.keterangan = 'sakit') as total_sakit,
            SUM(a.keterangan = 'izin') as total_izin
            FROM absensi a 
            JOIN siswa s ON a.siswa_id = s.id 
            JOIN kelas k ON s.kelas_id = k.id 
            WHERE YEAR(a.tanggal) = :tahun";

    if (!empty($kelas_id)) {
        $sql .= " AND s.kelas_id = :kelas_id";
    }

    $sql .= " GROUP BY s.id, k.id
              ORDER BY k.nama_kelas, s.nama";

    $stmt = $conn->prepare($sql);
    $params = ['tahun' => $tahun];

    if (!empty($kelas_id)) {
        $params['kelas_id'] = $kelas_id;
    }

    $stmt->execute($params);
    $rekap = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($rekap)) {
        echo "No data found for the given year and class.";
        exit;
    }

    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();
    $sheet->setCellValue('A1', 'Kelas');
    $sheet->setCellValue('B1', 'Nama Siswa');
    $sheet->setCellValue('C1', 'Total Alpha');
    $sheet->setCellValue('D1', 'Total Sakit');
    $sheet->setCellValue('E1', 'Total Izin');

    $row = 2;
    foreach ($rekap as $r) {
        $sheet->setCellValue('A' . $row, $r['nama_kelas']);
        $sheet->setCellValue('B' . $row, $r['nama']);
        $sheet->setCellValue('C' . $row, $r['total_alpha']);
        $sheet->setCellValue('D' . $row, $r['total_sakit']);
        $sheet->setCellValue('E' . $row, $r['total_izin']);
        $row++;
    }

    $filename = "rekap_absensi_tahun_$tahun.xlsx";

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header("Content-Disposition: attachment; filename=\"$filename\"");

    $writer = new Xlsx($spreadsheet);
    $writer->save("php://output");
    exit;
}
