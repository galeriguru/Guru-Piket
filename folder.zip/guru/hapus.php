<?php
include '../config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['tanggal'])) {
    $tanggal = $_POST['tanggal'];

    $stmt = $conn->prepare("SELECT a.id, a.tanggal, s.nama, k.nama_kelas, a.keterangan 
                            FROM absensi a 
                            JOIN siswa s ON a.siswa_id = s.id 
                            JOIN kelas k ON s.kelas_id = k.id 
                            WHERE a.tanggal = :tanggal
                            ORDER BY k.nama_kelas, s.nama");
    $stmt->execute(['tanggal' => $tanggal]);
    $absensi = $stmt->fetchAll(PDO::FETCH_ASSOC);
} elseif (isset($_GET['tanggal'])) {
    $tanggal = $_GET['tanggal'];

    $stmt = $conn->prepare("SELECT a.id, a.tanggal, s.nama, k.nama_kelas, a.keterangan 
                            FROM absensi a 
                            JOIN siswa s ON a.siswa_id = s.id 
                            JOIN kelas k ON s.kelas_id = k.id 
                            WHERE a.tanggal = :tanggal
                            ORDER BY k.nama_kelas, s.nama");
    $stmt->execute(['tanggal' => $tanggal]);
    $absensi = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hapus Absensi Siswa</title>
    <link rel="icon" href="../img/logo.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            width: 100%;
            max-width: 400px;
            box-sizing: border-box;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
        }

        input[type="date"],
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        table {
            width: 100%;
            max-width: 800px;
            margin-top: 20px;
            border-collapse: collapse;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            background-color: #fff;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            transition: background-color 0.3s;
        }

        th {
            background-color: #007bff;
            color: #fff;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f8f9fa;
        }

        tr:hover {
            background-color: #e9ecef;
        }

        .delete-button {
            padding: 5px 10px;
            color: white;
            background-color: #dc3545;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .delete-button:hover {
            background-color: #c82333;
        }

        .no-data {
            text-align: center;
            padding: 20px;
            color: #777;
        }

        @media (max-width: 600px) {
            body {
                padding: 10px;
            }

            form {
                padding: 15px;
            }

            table, th, td {
                font-size: 14px;
            }

            th, td {
                padding: 8px;
            }
        }
    </style>
</head>
<body>
    <h1>Hapus Absensi Siswa</h1>
    <form method="post" action="hapus.php">
        <label for="tanggal">Tanggal:</label>
        <input type="date" name="tanggal" id="tanggal" required>
        <input type="submit" value="Cek Absensi">
    </form>

    <?php if (isset($absensi)): ?>
        <h2>Absensi pada Tanggal <?= htmlspecialchars($tanggal) ?></h2>
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kelas</th>
                    <th>Nama Siswa</th>
                    <th>Keterangan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($absensi) > 0): ?>
                    <?php $no = 1; ?>
                    <?php foreach ($absensi as $a): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= htmlspecialchars($a['nama_kelas']) ?></td>
                        <td><?= htmlspecialchars($a['nama']) ?></td>
                        <td><?= htmlspecialchars($a['keterangan']) ?></td>
                        <td>
                            <form method="post" action="hapus_absensi.php" onsubmit="return confirm('Anda yakin ingin menghapus data ini?');">
                                <input type="hidden" name="id" value="<?= htmlspecialchars($a['id']) ?>">
                                <input type="hidden" name="tanggal" value="<?= htmlspecialchars($tanggal) ?>">
                                <button type="submit" class="delete-button">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="no-data">Tidak ada siswa yang absen pada tanggal ini.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    <?php endif; ?>
</body>
</html>
