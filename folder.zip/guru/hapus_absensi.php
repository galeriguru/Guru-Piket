<?php
include '../config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['id']) && isset($_POST['tanggal'])) {
        $id = $_POST['id'];
        $tanggal = $_POST['tanggal'];

        // Validasi data yang diterima
        if (is_numeric($id) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal)) {
            try {
                // Query untuk menghapus data absensi berdasarkan ID
                $stmt = $conn->prepare("DELETE FROM absensi WHERE id = :id");
                $stmt->execute(['id' => $id]);

                // Redirect kembali ke halaman hapus.php dengan parameter tanggal yang sama
                header("Location: hapus.php?tanggal=" . urlencode($tanggal));
                exit();
            } catch (PDOException $e) {
                // Tampilkan pesan kesalahan jika terjadi masalah
                echo "Kesalahan: " . htmlspecialchars($e->getMessage());
            }
        } else {
            // Jika data tidak valid, kembali ke halaman hapus.php dengan pesan
            header("Location: hapus.php?error=invalid_data");
            exit();
        }
    } else {
        // Jika tidak ada data POST yang sesuai, kembali ke halaman hapus.php
        header("Location: hapus.php");
        exit();
    }
} else {
    // Jika tidak ada data POST, kembalikan ke halaman hapus.php
    header("Location: hapus.php");
    exit();
}
?>
