<?php
require '../config.php';

// Get total students
try {
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM siswa");
    $stmt->execute();
    $total_siswa = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
} catch (PDOException $e) {
    $total_siswa = 0;
}

// Get total classes
try {
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM kelas");
    $stmt->execute();
    $total_kelas = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
} catch (PDOException $e) {
    $total_kelas = 0;
}

// Get today's attendance
try {
    $stmt = $conn->prepare("
        SELECT keterangan, COUNT(*) as total 
        FROM absensi 
        WHERE DATE(tanggal) = CURDATE() 
        GROUP BY keterangan
    ");
    $stmt->execute();
    $absensi_hari_ini = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $total_sakit = 0;
    $total_izin = 0;
    $total_alpha = 0;
    
    foreach($absensi_hari_ini as $absen) {
        switch($absen['keterangan']) {
            case 'sakit':
                $total_sakit = $absen['total'];
                break;
            case 'izin':
                $total_izin = $absen['total'];
                break;
            case 'alpha':
                $total_alpha = $absen['total'];
                break;
        }
    }

    // Hitung total hadir
    $total_tidak_hadir = $total_sakit + $total_izin + $total_alpha;
    $total_hadir = $total_siswa - $total_tidak_hadir;

} catch (PDOException $e) {
    $total_hadir = $total_sakit = $total_izin = $total_alpha = 0;
}

// Get attendance data for the last 7 days
try {
    $stmt = $conn->prepare("
        SELECT DATE(tanggal) as tanggal, keterangan, COUNT(*) as total
        FROM absensi
        WHERE tanggal >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        GROUP BY DATE(tanggal), keterangan
        ORDER BY tanggal
    ");
    $stmt->execute();
    $weekly_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format data for chart
    $chart_data = [];
    foreach($weekly_data as $data) {
        $date = date('d/m', strtotime($data['tanggal']));
        if (!isset($chart_data[$date])) {
            $chart_data[$date] = [
                'tanggal' => $date,
                'hadir' => 0,
                'sakit' => 0,
                'izin' => 0,
                'alpha' => 0
            ];
        }
        $chart_data[$date][$data['keterangan']] = $data['total'];
    }
    $chart_data = array_values($chart_data);
} catch (PDOException $e) {
    $chart_data = [];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Absensi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        .dashboard-card {
            border-radius: 15px;
            border: none;
            transition: transform 0.3s;
        }
        .dashboard-card:hover {
            transform: translateY(-5px);
        }
        .card-icon {
            width: 48px;
            height: 48px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .bg-gradient-primary {
            background: linear-gradient(45deg, #4776E6, #8E54E9);
        }
        .bg-gradient-success {
            background: linear-gradient(45deg, #2ecc71, #27ae60);
        }
        .bg-gradient-warning {
            background: linear-gradient(45deg, #f1c40f, #f39c12);
        }
        .bg-gradient-danger {
            background: linear-gradient(45deg, #e74c3c, #c0392b);
        }
        footer {
            background-color: #343a40;
            color: white;
            padding: 10px 0;
            text-align: center;
            position: relative;
            bottom: 0;
            width: 100%;
        }
        footer a {
            color: #f8f9fa;
            text-decoration: none;
        }
        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body class="bg-light">
    <div class="container-fluid py-4">
        <h1 class="mb-4">Dashboard Absensi</h1>
        
        <!-- Statistik Cards -->
        <div class="row g-4 mb-4">
            <div class="col-xl-3 col-sm-6">
                <div class="card dashboard-card shadow-sm">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="card-icon bg-gradient-primary text-white me-3">
                                <i class="bi bi-people-fill"></i>
                            </div>
                            <div>
                                <h6 class="card-subtitle mb-1 text-muted">Total Siswa</h6>
                                <h2 class="card-title mb-0"><?php echo $total_siswa; ?></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-sm-6">
                <div class="card dashboard-card shadow-sm">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="card-icon bg-gradient-success text-white me-3">
                                <i class="bi bi-grid-3x3-gap-fill"></i>
                            </div>
                            <div>
                                <h6 class="card-subtitle mb-1 text-muted">Total Kelas</h6>
                                <h2 class="card-title mb-0"><?php echo $total_kelas; ?></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-sm-6">
                <div class="card dashboard-card shadow-sm">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="card-icon bg-gradient-warning text-white me-3">
                                <i class="bi bi-calendar-check-fill"></i>
                            </div>
                            <div>
                                <h6 class="card-subtitle mb-1 text-muted">Hadir Hari Ini</h6>
                                <h2 class="card-title mb-0"><?php echo $total_hadir; ?></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-sm-6">
                <div class="card dashboard-card shadow-sm">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="card-icon bg-gradient-danger text-white me-3">
                                <i class="bi bi-exclamation-triangle-fill"></i>
                            </div>
                            <div>
                                <h6 class="card-subtitle mb-1 text-muted">Tidak Hadir</h6>
                                <h2 class="card-title mb-0"><?php echo $total_sakit + $total_izin + $total_alpha; ?></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tombol Navigasi -->
        <div class="row mb-4">
            <div class="col">
                <div class="card shadow-sm">
                    <div class="card-header bg-white">
                        <h5 class="card-title mb-0">Navigasi</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-4">
                                <a href="cek_absensi.php" class="btn btn-primary btn-custom">Cek Absensi</a>
                            </div>
                            <div class="col-4">
                                <a href="rekap_bulanan.php" class="btn btn-success btn-custom">Rekap Bulanan</a>
                            </div>
                            <div class="col-4">
                                <a href="rekap_absensi.php" class="btn btn-warning btn-custom">Rekap Absensi</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Grafik dan Detail Absensi -->
        <div class="row g-4">
            <div class="col-xl-8">
                <div class="card shadow-sm">
                    <div class="card-header bg-white">
                        <h5 class="card-title mb-0">Grafik Absensi 7 Hari Terakhir</h5>
                    </div>
                    <div class="card-body">
                        <div id="attendance-chart" style="width: 100%; height: 400px;"></div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-4">
                <div class="card shadow-sm">
                    <div class="card-header bg-white">
                        <h5 class="card-title mb-0">Detail Absensi Hari Ini</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-4">
                            <div class="d-flex justify-content-between mb-2">
                                <span class="text-success">Hadir</span>
                                <span class="fw-bold"><?php echo $total_hadir; ?> Siswa</span>
                            </div>
                            <div class="progress">
                                <div class="progress-bar bg-success" style="width: <?php echo ($total_siswa > 0) ? ($total_hadir/$total_siswa*100) : 0; ?>%"></div>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <div class="d-flex justify-content-between mb-2">
                                <span class="text-warning">Sakit</span>
                                <span class="fw-bold"><?php echo $total_sakit; ?> Siswa</span>
                            </div>
                            <div class="progress">
                                <div class="progress-bar bg-warning" style="width: <?php echo ($total_siswa > 0) ? ($total_sakit/$total_siswa*100) : 0; ?>%"></div>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <div class="d-flex justify-content-between mb-2">
                                <span class="text-info">Izin</span>
                                <span class="fw-bold"><?php echo $total_izin; ?> Siswa</span>
                            </div>
                            <div class="progress">
                                <div class="progress-bar bg-info" style="width: <?php echo ($total_siswa > 0) ? ($total_izin/$total_siswa*100) : 0; ?>%"></div>
                            </div>
                        </div>
                        
                        <div>
                            <div class="d-flex justify-content-between mb-2">
                                <span class="text-danger">Alpha</span>
                                <span class="fw-bold"><?php echo $total_alpha; ?> Siswa</span>
                            </div>
                            <div class="progress">
                                <div class="progress-bar bg-danger" style="width: <?php echo ($total_siswa > 0) ? ($total_alpha/$total_siswa*100) : 0; ?>%"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer>
        <div class="container">
            <p class="mb-0">Support by <a href="https://galeriguru.my.id" target="_blank">Koala</a> from <a href="https://galeriguru.my.id" target="_blank">galeriguru.my.id</a></p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <script>
        // Data dari PHP untuk grafik
        const chartData = <?php echo json_encode($chart_data); ?>;
        
        // Konfigurasi grafik
        const options = {
            series: [{
                name: 'Hadir',
                data: chartData.map(item => item.hadir)
            }, {
                name: 'Sakit',
                data: chartData.map(item => item.sakit)
            }, {
                name: 'Izin',
                data: chartData.map(item => item.izin)
            }, {
                name: 'Alpha',
                data: chartData.map(item => item.alpha)
            }],
            chart: {
                type: 'area',
                height: 400,
                stacked: true,
                toolbar: {
                    show: false
                }
            },
            dataLabels: {
                enabled: false
            },
            xaxis: {
                categories: chartData.map(item => item.tanggal)
            },
            colors: ['#2ecc71', '#f1c40f', '#3498db', '#e74c3c'],
            fill: {
                type: 'gradient',
                gradient: {
                    opacityFrom: 0.6,
                    opacityTo: 0.1
                }
            }
        };

        const chart = new ApexCharts(document.querySelector("#attendance-chart"), options);
        chart.render();
    </script>
</body>
</html>