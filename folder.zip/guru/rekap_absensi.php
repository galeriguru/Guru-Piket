<?php
include '../config.php';

// Mengambil tahun-tahun dari database atau mendefinisikan secara manual
$years = range(date('Y') - 3, date('Y')); // Menampilkan tahun dari 3 tahun terakhir hingga tahun sekarang

// Ambil data kelas dari database untuk dropdown
$stmt = $conn->query("SELECT * FROM kelas");
$kelasList = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tahun = $_POST['tahun'];
    $kelas_id = $_POST['kelas_id'] ?? '';

    // Query untuk menyertakan filter kelas jika dipilih
    $sql = "SELECT s.nama, k.nama_kelas, 
            SUM(a.keterangan = 'alpha') as total_alpha,
            SUM(a.keterangan = 'sakit') as total_sakit,
            SUM(a.keterangan = 'izin') as total_izin
            FROM absensi a 
            JOIN siswa s ON a.siswa_id = s.id 
            JOIN kelas k ON s.kelas_id = k.id 
            WHERE YEAR(a.tanggal) = :tahun";

    if (!empty($kelas_id)) {
        $sql .= " AND s.kelas_id = :kelas_id";
    }

    $sql .= " GROUP BY s.id, k.id
              ORDER BY k.nama_kelas, s.nama";
    
    $stmt = $conn->prepare($sql);
    $params = ['tahun' => $tahun];
    
    if (!empty($kelas_id)) {
        $params['kelas_id'] = $kelas_id;
    }

    $stmt->execute($params);
    $rekap = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../img/logo.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Absensi</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .form-container {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .form-group {
            display: flex;
            gap: 10px;
            align-items: center;
            flex-wrap: wrap;
        }

        select, input[type="submit"], .download-button {
            padding: 9px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        input[type="submit"] {
            background-color: #007BFF;
            color: white;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .download-button {
            background-color: #28a745;
            color: white;
            cursor: pointer;
        }

        .download-button:hover {
            background-color: #218838;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: left;
        }

        th {
            background-color: #007BFF;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        @media (max-width: 600px) {
            .form-container {
                flex-direction: column;
                align-items: stretch;
            }

            select, input[type="submit"], .download-button {
                width: 100%;
                margin-bottom: 10px;
            }

            .form-group {
                flex-direction: column;
                align-items: stretch;
            }
        }
    </style>
</head>
<body>
    <h1>Rekap Absensi</h1>
    <div class="form-container">
        <div class="form-group">
            <form method="post" action="rekap_absensi.php">
                <label for="tahun">Tahun:</label>
                <select name="tahun" id="tahun" required>
                    <?php foreach ($years as $year): ?>
                        <option value="<?= $year ?>" <?= (isset($tahun) && $tahun == $year) ? 'selected' : '' ?>>
                            <?= $year ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <label for="kelas">Kelas:</label>
                <select name="kelas_id" id="kelas">
                    <option value="">Semua Kelas</option>
                    <?php foreach ($kelasList as $k): ?>
                        <option value="<?= $k['id'] ?>" <?= (isset($kelas_id) && $kelas_id == $k['id']) ? 'selected' : '' ?>>
                            <?= $k['nama_kelas'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <input type="submit" value="Cek Rekap">  
            </form>

            <?php if (isset($rekap)): ?>
                <form method="post" action="download_excel.php">
                    <input type="hidden" name="tahun" value="<?= htmlspecialchars($tahun) ?>">
                    <input type="hidden" name="kelas_id" value="<?= htmlspecialchars($kelas_id ?? '') ?>">
                    <input type="submit" class="download-button" value="Download Excel">
                </form>
            <?php endif; ?>
        </div>
    </div>

    <?php if (isset($rekap)): ?>
        <h2>Rekap Absensi Tahun <?= htmlspecialchars($tahun) ?> <?= !empty($kelas_id) ? "Kelas " . $kelasList[array_search($kelas_id, array_column($kelasList, 'id'))]['nama_kelas'] : '' ?></h2>
        <table>
            <tr>
                <th>No</th>
                <th>Nama Siswa</th>
                <th>Kelas</th>
                <th>Total Alpha</th>
                <th>Total Sakit</th>
                <th>Total Izin</th>
            </tr>
            <?php if (count($rekap) > 0): ?>
                <?php $no = 1; ?>
                <?php foreach ($rekap as $r): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= htmlspecialchars($r['nama']) ?></td>
                    <td><?= htmlspecialchars($r['nama_kelas']) ?></td>
                    <td><?= htmlspecialchars($r['total_alpha']) ?></td>
                    <td><?= htmlspecialchars($r['total_sakit']) ?></td>
                    <td><?= htmlspecialchars($r['total_izin']) ?></td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">Tidak ada data absensi untuk tahun ini.</td>
                </tr>
            <?php endif; ?>
        </table>
    <?php endif; ?>
</body>
</html>
