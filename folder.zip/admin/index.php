<?php
require '../config.php';

// Ambil total siswa
try {
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM siswa");
    $stmt->execute();
    $total_siswa = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
} catch (PDOException $e) {
    $total_siswa = 0;
}

// Ambil data absensi hari ini
try {
    $stmt = $conn->prepare("
        SELECT keterangan, COUNT(*) as total 
        FROM absensi 
        WHERE DATE(tanggal) = CURDATE() 
        GROUP BY keterangan
    ");
    $stmt->execute();
    $absensi_hari_ini = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $total_izin = 0;
    $total_sakit = 0;
    $total_alpha = 0;

    foreach ($absensi_hari_ini as $absen) {
        if ($absen['keterangan'] == 'izin') {
            $total_izin = $absen['total'];
        } elseif ($absen['keterangan'] == 'sakit') {
            $total_sakit = $absen['total'];
        } elseif ($absen['keterangan'] == 'alpha') {
            $total_alpha = $absen['total'];
        }
    }

    // Hitung jumlah siswa hadir
    $total_tidak_hadir = $total_izin + $total_sakit + $total_alpha;
    $total_hadir = $total_siswa - $total_tidak_hadir;
} catch (PDOException $e) {
    $total_hadir = $total_tidak_hadir = 0;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background-color: #e9ecef;
        }
        .container {
            margin-top: 50px;
        }
        .card {
            border-radius: 15px;
            transition: transform 0.2s;
        }
        .card:hover {
            transform: scale(1.05);
        }
        .btn-custom {
            border-radius: 20px;
            margin: 10px;
        }
        .header {
            background: linear-gradient(45deg, #6a11cb, #2575fc);
            color: white;
            padding: 20px;
            border-radius: 15px;
            text-align: center;
        }
        .chart-container {
            position: relative;
            margin-top: 10px;
            max-width: 250px; /* Ukuran maksimum untuk grafik */
            margin-left: auto; /* Centering */
            margin-right: auto; /* Centering */
        }
        footer {
            background-color: #343a40;
            color: white;
            text-align: center;
            position: relative;
            bottom: 0;
            width: 100%;
            max-height: 60px; /* Tambahkan tinggi minimum */
        }

        footer a {
            color: #f8f9fa;
            text-decoration: none;
        }
        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Dashboard Home</h1>
            <p>Selamat datang di sistem absensi</p>
        </div>

        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h5 class="card-title">Total Siswa</h5>
                        <h2 class="card-text"><?php echo $total_siswa; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h5 class="card-title">Hadir Hari Ini</h5>
                        <h2 class="card-text"><?php echo $total_hadir; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h5 class="card-title">Tidak Hadir</h5>
                        <h2 class="card-text"><?php echo $total_tidak_hadir; ?></h2>
                    </div>
                </div>
            </div>
        </div>

        <div class="chart-container">
            <canvas id="attendanceChart" height="300"></canvas> <!-- Ukuran grafik lebih kecil -->
        </div>

        <div class="text-center">
            <a href="add_siswa.php" class="btn btn-primary btn-custom">Tambah Siswa</a>
            <a href="del_siswa.php" class="btn btn-danger btn-custom">Hapus Siswa</a>
        </div>
    </div>

    <script>
        const ctx = document.getElementById('attendanceChart').getContext('2d');
        const attendanceChart = new Chart(ctx, {
            type: 'pie', // Menggunakan diagram lingkaran
            data: {
                labels: ['Hadir', 'Izin', 'Sakit', 'Alpha'],
                datasets: [{
                    label: 'Jumlah Siswa',
                    data: [<?php echo $total_hadir; ?>, <?php echo $total_izin; ?>, <?php echo $total_sakit; ?>, <?php echo $total_alpha; ?>],
                    backgroundColor: [
                        'rgba(75, 192, 192, 0.6)',
                        'rgba(255, 206, 86, 0.6)',
                        'rgba(255, 99, 132, 0.6)',
                        'rgba(153, 102, 255, 0.6)'
                    ],
                    borderColor: [
                        'rgba(75, 192, 192, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(255, 99, 132, 1)',
                        'rgba(153, 102, 255, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                    },
                }
            }
        });
    </script>
    <footer>
        <div class="container">
            <p class="mb-0">Support by <a href="https://galeriguru.my.id" target="_blank">Koala</a> from <a href="https://galeriguru.my.id" target="_blank">galeriguru.my.id</a></p>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>