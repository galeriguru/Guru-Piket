<?php
require '../config.php';

// Ambil data kelas untuk dropdown
try {
    $stmt = $conn->prepare("SELECT * FROM kelas");
    $stmt->execute();
    $kelas_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $kelas_list = [];
}

// Proses penghapusan siswa
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $delete_id = $_POST['delete_id'];
    try {
        $stmt = $conn->prepare("DELETE FROM siswa WHERE id = :id");
        $stmt->bindParam(':id', $delete_id);
        $stmt->execute();
        $message = "Siswa berhasil dihapus.";
    } catch (PDOException $e) {
        $message = "Gagal menghapus siswa: " . $e->getMessage();
    }
}

// Ambil siswa berdasarkan kelas yang dipilih
$siswa_list = [];
if (isset($_POST['kelas_id'])) {
    $kelas_id = $_POST['kelas_id'];
    try {
        $stmt = $conn->prepare("SELECT * FROM siswa WHERE kelas_id = :kelas_id");
        $stmt->bindParam(':kelas_id', $kelas_id);
        $stmt->execute();
        $siswa_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $siswa_list = [];
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hapus Siswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        .card {
            border-radius: 15px;
        }
        .btn-danger {
            border-radius: 20px;
        }
        .btn-back {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center mb-4">Hapus Siswa</h1>

        <?php if (isset($message)): ?>
            <div class="alert alert-info"><?php echo $message; ?></div>
        <?php endif; ?>

        <div class="card shadow-sm">
            <div class="card-body">
                <form method="POST" action="">
                    <div class="mb-3">
                        <label for="kelas_id" class="form-label">Pilih Kelas</label>
                        <select name="kelas_id" id="kelas_id" class="form-select" required>
                            <option value="">-- Pilih Kelas --</option>
                            <?php foreach ($kelas_list as $kelas): ?>
                                <option value="<?php echo $kelas['id']; ?>"><?php echo $kelas['nama_kelas']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Tampilkan Siswa</button>
                </form>
            </div>
        </div>

        <?php if (!empty($siswa_list)): ?>
            <div class="card shadow-sm mt-4">
                <div class="card-header">
                    <h5 class="mb-0">Daftar Siswa</h5>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nama Siswa</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($siswa_list as $siswa): ?>
                                <tr>
                                    <td><?php echo $siswa['id']; ?></td>
                                    <td><?php echo $siswa['nama']; ?></td>
                                    <td>
                                        <form method="POST" action="">
                                            <input type="hidden" name="delete_id" value="<?php echo $siswa['id']; ?>">
                                            <button type="submit" class="btn btn-danger">Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        <div class="text-center">
            <a href="index.php" class="btn btn-secondary btn-back">Kembali ke Beranda</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>