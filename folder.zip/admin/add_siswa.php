<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!file_exists('../config.php')) {
    die("Error: File config.php tidak ditemukan!");
}

require '../config.php';

// Cek koneksi database
if (!isset($conn)) {
    die("Error: Koneksi database tidak tersedia");
}

$success_message = $error_message = "";

// Proses form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validasi input
    $nama = trim($_POST['nama'] ?? '');
    $kelas_id = filter_var($_POST['kelas_id'] ?? 0, FILTER_VALIDATE_INT);
    
    $errors = [];
    
    if (empty($nama)) {
        $errors[] = "Nama siswa tidak boleh kosong";
    }
    
    if (!$kelas_id) {
        $errors[] = "Kelas harus dipilih";
    }
    
    if (empty($errors)) {
        try {
            $sql = "INSERT INTO siswa (nama, kelas_id) VALUES (:nama, :kelas_id)";
            $stmt = $conn->prepare($sql);
            
            $stmt->bindParam(':nama', $nama, PDO::PARAM_STR);
            $stmt->bindParam(':kelas_id', $kelas_id, PDO::PARAM_INT);
            
            if ($stmt->execute()) {
                $success_message = "Data siswa berhasil ditambahkan!";
                // Clear input setelah berhasil
                $nama = '';
                $kelas_id = '';
            } else {
                throw new Exception("Error dalam menjalankan query");
            }
        } catch (PDOException $e) {
            $error_message = "Error Database: " . $e->getMessage();
        } catch (Exception $e) {
            $error_message = "Error: " . $e->getMessage();
        }
    } else {
        $error_message = "Error: " . implode(", ", $errors);
    }
}

// Ambil data kelas untuk dropdown
try {
    $sql_kelas = "SELECT * FROM kelas ORDER BY nama_kelas";
    $stmt_kelas = $conn->prepare($sql_kelas);
    $stmt_kelas->execute();
    $result_kelas = $stmt_kelas->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Siswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .gradient-custom {
            background: linear-gradient(to right, #4776E6, #8E54E9);
            min-height: 100vh;
        }
        .card {
            margin-top: 20px;
        }
        .alert {
            margin-bottom: 20px;
        }
    </style>
</head>
<body class="gradient-custom">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Tambah Data Siswa</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($success_message): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo htmlspecialchars($success_message); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($error_message): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <?php echo htmlspecialchars($error_message); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="needs-validation" novalidate>
                            <div class="mb-3">
                                <label for="nama" class="form-label">Nama Siswa</label>
                                <input type="text" class="form-control" id="nama" name="nama" 
                                       value="<?php echo htmlspecialchars($nama ?? ''); ?>" required>
                                <div class="invalid-feedback">
                                    Mohon isi nama siswa
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="kelas_id" class="form-label">Kelas</label>
                                <select class="form-select" id="kelas_id" name="kelas_id" required>
                                    <option value="">Pilih Kelas</option>
                                    <?php foreach($result_kelas as $row): ?>
                                        <option value="<?php echo $row['id']; ?>" 
                                                <?php echo (isset($kelas_id) && $kelas_id == $row['id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($row['nama_kelas']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="invalid-feedback">
                                    Mohon pilih kelas
                                </div>
                            </div>
                            
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">Simpan Data</button>
                                <button type="reset" class="btn btn-secondary">Reset</button>
                                <div class="text-center">
                                    <a href="index.php" class="btn btn-secondary btn-back">Kembali ke Beranda</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        (function () {
            'use strict'
            var forms = document.querySelectorAll('.needs-validation')
            Array.prototype.slice.call(forms)
                .forEach(function (form) {
                    form.addEventListener('submit', function (event) {
                        if (!form.checkValidity()) {
                            event.preventDefault()
                            event.stopPropagation()
                        }
                        form.classList.add('was-validated')
                    }, false)
                })
        })()
    </script>
</body>
</html>